waf.sflash_write-NoOS-ISM43903_R48_L54-SOC.43909.elf supports Cypress and Micron Flash
